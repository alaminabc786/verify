<!--
Want to use an HTML or PHP file as your homepage?

Edit file config.php
Find the line "default"=>"xxxx" and change it to "default"=>"homepage"

This will make this file the homepage! Edit this file to your liking!
-->
<html>
<head>
	<title>Homepage</title>
</head>
<body>
<p>Edit this page in /homepage.php.</p>
</body>
</html>